a=input("Enter the string:")
b=" "
for i in a:
    if i not in b:
        b=b+i
c=" "
for i in a:
    if(ord(i)>=97 and ord(i)<=122 or ord(i)==32 or ord(i)>=65 and ord(i)<=90):
        c=c+i
d=" "
for i in a:
    if (ord(i)>=97 and ord(i)<=122):
        d=d+chr(ord(i)-32)
    elif (ord(i)>=65 and ord(i)<=90):
        d=d+chr(ord(i)+32)
    else:
        d=d+i
print("the string after removing duplicates is:",b)
print("the string after removing special characters is:",c)
print("the string after changing case is:",d)