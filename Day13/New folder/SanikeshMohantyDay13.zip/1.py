class circle:
    def __init__(self,x,y,r):
        self.x = x
        self.y = y
        self.r = r

c1=circle(int(input("enter the x co-ordinate of 1st circle")),int(input("enter the y co-ordinate of 1st circle")),int(input("enter the radius of 1st circle")))
c2=circle(int(input("enter the x co-ordinate of 2nd circle")),int(input("enter the y co-ordinate of 2nd circle")),int(input("enter the radius of 2nd circle")))
centdis=(((c1.x-c2.x)**2)-((c1.y-c2.y)**2))**0.5
radis=float(c1.r+c2.r)
if centdis==radis:
    print("the circle touches each other")
elif centdis<radis:
    print("the circles intersect each other")
else:
    print("the circles do not touch")
