r1=int(input("enter the number of rows of 1st matrix:"))
c1=int(input("enter the number columns of 1st matrix:"))
print("enter 1st matrix elements:")
x=[[int(input()) for i in range(c1)] for j in range(r1)]
r2=int(input("enter the number of rows of 2nd matrix:"))
c2=int(input("enter the number of columns of 2nd matrix:"))
y=[[int(input()) for i in range(c2)] for j in range(r2)]
r=0
result=[[r for i in range(c2)] for j in range(r1)]

for i in range(len(x)):
    for j in range(len(y[0])):
        for k in range(len(y)):
            result[i][j]+=x[i][k]*y[k][j]
print("resultant matrix after multiplication:\n")
for i in result:
    print(i)
