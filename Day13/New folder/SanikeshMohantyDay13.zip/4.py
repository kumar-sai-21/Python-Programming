print("enter 2*2 square matrix elements:")
a=[[int(input()) for i in range(2)] for j in range(2)]
print("DETERMINANT:",(a[0][0]*a[1][1])-(a[0][1]*a[1][0]))
