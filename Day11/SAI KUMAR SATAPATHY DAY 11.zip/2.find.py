# find UU in the .txt
import os
import open_file
for items in open_file.word_cls:
    if 'UU' in items:
        print(items)
