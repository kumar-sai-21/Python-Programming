import os
import open_file
#print(open_file.my_word)
#print(open_file.word_cls)
print(open_file.word_cls[:10])