#1. Check if a given input number is a perfect square
#SAI KUMAR STAPATHY
n=int(input("enter the number"))
if (n**0.5==int(n**0.5)):
    print("perfect square")
else:
    print("not a perfect square")
