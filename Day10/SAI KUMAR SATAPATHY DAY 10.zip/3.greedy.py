#Items = (value, weight)
#Items = [(60, 10), (100, 20), (120, 30)]
#capacity = 50
def out(l,bag):
    cont=0
    for i in l:
        weight=i[1]
        value=i[0]
        if(weight<=bag):
            bag=bag-weight
            cont=cont+value
        else :
            weight=i[2]
            cont=cont+(weight*bag)
    print(cont)
x=input("Enter values :").split()
y=input("Enter weight :").split()
l=[(int(x[i]),int(y[i]),int(x[i])/int(y[i]))for i in range (len(x))]
l=sorted(l,key=lambda i:i[len(i)-1],reverse=True)
print(l)
bag=int(input("Enter capacity of the bag :"))
out(l,bag)
    
        

