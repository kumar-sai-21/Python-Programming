#Write a program to find consonants in a string 
#SAI KUMAR SATAPATHY
list=input("enter a string ")
vowel=0
for ch in list:
    if(ch =='a' or ch=='e' or ch=='i' or ch=='o' or ch=='u' or ch =='A' or ch=='E' or ch=='I' or ch=='O' or ch=='U'):
        pass
    else:
        print("the consonants are : ",ch)


